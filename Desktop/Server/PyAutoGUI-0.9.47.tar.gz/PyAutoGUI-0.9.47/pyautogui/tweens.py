import pytweening


# This is just left here for backwards compatibility. I'll be deprecating this in favor of pyautogui.linear, pyautogui.easeInQuad, etc.
getPointOnLine = pytweening.getPointOnLine
linear = pytweening.linear
easeInQuad = pytweening.easeInQuad
easeOutQuad = pytweening.easeOutQuad
easeInOutQuad = pytweening.easeInOutQuad
easeInCubic = pytweening.easeInCubic
easeOutCubic = pytweening.easeOutCubic
easeInOutCubic = pytweening.easeInOutCubic
easeInQuart = pytweening.easeInQuart
easeOutQuart = pytweening.easeOutQuart
easeInOutQuart = pytweening.easeInOutQuart
easeInQuint = pytweening.easeInQuint
easeOutQuint = pytweening.easeOutQuint
easeInOutQuint = pytweening.easeInOutQuint
easeInSine = pytweening.easeInSine
easeOutSine = pytweening.easeOutSine
easeInOutSine = pytweening.easeInOutSine
easeInExpo = pytweening.easeInExpo
easeOutExpo = pytweening.easeOutExpo
easeInOutExpo = pytweening.easeInOutExpo
easeInCirc = pytweening.easeInCirc
easeOutCirc = pytweening.easeOutCirc
easeInOutCirc = pytweening.easeInOutCirc
easeInElastic = pytweening.easeInElastic
easeOutElastic = pytweening.easeOutElastic
easeInOutElastic = pytweening.easeInOutElastic
easeInBack = pytweening.easeInBack
easeOutBack = pytweening.easeOutBack
easeInOutBack = pytweening.easeInOutBack
easeInBounce = pytweening.easeInBounce
easeOutBounce = pytweening.easeOutBounce
easeInOutBounce = pytweening.easeInOutBounce
